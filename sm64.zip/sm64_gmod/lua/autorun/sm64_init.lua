-- SM64 for GMod: loader. Everything lives under the global SM64 table.
SM64 = SM64 or {}
SM64.SCALE    = 0.45                    -- Source units per SM64 unit (Mario ~160 SM64 units ~ 72 Source)
SM64.ROM_PATH = "sm64/baserom.us.z64"   -- relative to garrysmod/data/ ; each player supplies their own US ROM

if SERVER then
	AddCSLuaFile("sm64/cl_surfaces.lua")
	AddCSLuaFile("sm64/cl_sm64.lua")
	include("sm64/sv_sm64.lua")
else
	include("sm64/cl_surfaces.lua")
	include("sm64/cl_sm64.lua")
end
