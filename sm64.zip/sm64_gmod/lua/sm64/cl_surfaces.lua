-- Client: gets map collision triangles and uploads them to libsm64 as static surfaces.
SM64 = SM64 or {}
local cvFlip = CreateClientConVar("sm64_flip_winding", "0", true, false, "Flip triangle winding if Mario falls through floors")
local LIM = 32000 -- int16 limit; triangles outside are skipped

local function Upload(flat)
	local S, flip = SM64.SCALE, cvFlip:GetBool()
	local out, n = {}, 0
	for i = 1, #flat - 8, 9 do
		-- Source (x,y,z) -> SM64 (x, z, -y)
		local x1, y1, z1 = flat[i] / S,     flat[i + 2] / S, -flat[i + 1] / S
		local x2, y2, z2 = flat[i + 3] / S, flat[i + 5] / S, -flat[i + 4] / S
		local x3, y3, z3 = flat[i + 6] / S, flat[i + 8] / S, -flat[i + 7] / S
		if math.max(math.abs(x1), math.abs(y1), math.abs(z1), math.abs(x2), math.abs(y2), math.abs(z2),
			math.abs(x3), math.abs(y3), math.abs(z3)) <= LIM then
			if flip then x2, y2, z2, x3, y3, z3 = x3, y3, z3, x2, y2, z2 end
			local o = n * 9
			out[o + 1], out[o + 2], out[o + 3] = math.floor(x1 + 0.5), math.floor(y1 + 0.5), math.floor(z1 + 0.5)
			out[o + 4], out[o + 5], out[o + 6] = math.floor(x2 + 0.5), math.floor(y2 + 0.5), math.floor(z2 + 0.5)
			out[o + 7], out[o + 8], out[o + 9] = math.floor(x3 + 0.5), math.floor(y3 + 0.5), math.floor(z3 + 0.5)
			n = n + 1
		end
	end
	libsm64.LoadSurfaces(out, n)
	SM64.worldLoaded = true
	print("[SM64] loaded " .. n .. " collision triangles")
end

local chunks, got, pendingCb = {}, 0, nil

net.Receive("SM64_WorldChunk", function()
	local i, total, len = net.ReadUInt(16), net.ReadUInt(16), net.ReadUInt(16)
	if i == 1 then chunks, got = {}, 0 end
	chunks[i] = net.ReadData(len)
	got = got + 1
	if got >= total then
		local str = util.Decompress(table.concat(chunks)) or ""
		chunks, got = {}, 0
		local flat = {}
		for num in string.gmatch(str, "-?%d+") do flat[#flat + 1] = tonumber(num) end
		Upload(flat)
		if pendingCb then local cb = pendingCb pendingCb = nil cb() end
	end
end)

function SM64.LoadWorld(cb)
	if SM64.worldLoaded then return cb() end
	local phys = game.GetWorld():GetPhysicsObject()
	if IsValid(phys) then
		local m = phys:GetMesh()
		if m and #m > 0 then
			local flat = {}
			for i = 1, #m do
				local p = m[i].pos
				flat[#flat + 1], flat[#flat + 2], flat[#flat + 3] = p.x, p.y, p.z
			end
			Upload(flat)
			return cb()
		end
	end
	pendingCb = cb
	net.Start("SM64_WorldReq") net.SendToServer()
end
