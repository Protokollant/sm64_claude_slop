-- Server: toggles Mario mode, accepts (validated) position updates, serves world collision as a fallback.
util.AddNetworkString("SM64_Toggle")      -- server -> client
util.AddNetworkString("SM64_State")       -- client -> server (position)
util.AddNetworkString("SM64_WorldReq")    -- client -> server
util.AddNetworkString("SM64_WorldChunk")  -- server -> client

local MAX_SPEED  = 4000   -- Source units/sec sanity limit (Mario can be fast)
local MIN_PERIOD = 0.02   -- rate limit for SM64_State
local CHUNK      = 60000
local lastUpdate = {}

local function SetMario(ply, on)
	ply.SM64 = on or nil
	ply:SetMoveType(on and MOVETYPE_NOCLIP or MOVETYPE_WALK)
	lastUpdate[ply] = nil
	net.Start("SM64_Toggle") net.WriteBool(on) net.Send(ply)
end

concommand.Add("sm64_toggle", function(ply)
	if IsValid(ply) then SetMario(ply, not ply.SM64) end
end)

concommand.Add("sm64_respawn", function(ply)
	if not IsValid(ply) or not ply.SM64 then return end
	ply:Spawn()
	timer.Simple(0, function() if IsValid(ply) then SetMario(ply, true) end end)
end)

net.Receive("SM64_State", function(_, ply)
	if not ply.SM64 then return end
	local now = CurTime()
	local last = lastUpdate[ply]
	if last and now - last < MIN_PERIOD then return end
	local dt = last and math.min(now - last, 0.5) or 0.5
	lastUpdate[ply] = now

	local pos = net.ReadVector()
	if pos.x ~= pos.x or pos.y ~= pos.y or pos.z ~= pos.z then return end
	local maxd = MAX_SPEED * dt + 256
	if pos:DistToSqr(ply:GetPos()) > maxd * maxd then return end

	ply:SetPos(pos)
	ply:SetLocalVelocity(vector_origin)
end)

hook.Add("PlayerSwitchWeapon", "SM64_NoWeapons", function(ply) if ply.SM64 then return true end end)
hook.Add("PlayerDisconnected", "SM64_Cleanup", function(ply) lastUpdate[ply] = nil end)

-- Fallback world collision transfer (only used if the client can't read the world physmesh itself).
local blob
local function BuildBlob()
	if blob then return blob end
	local phys = game.GetWorld():GetPhysicsObject()
	if not IsValid(phys) then return end
	local m = phys:GetMesh()
	if not m then return end
	local flat = {}
	for i = 1, #m do
		local p = m[i].pos
		flat[#flat + 1] = math.Round(p.x)
		flat[#flat + 1] = math.Round(p.y)
		flat[#flat + 1] = math.Round(p.z)
	end
	blob = util.Compress(table.concat(flat, ","))
	return blob
end

net.Receive("SM64_WorldReq", function(_, ply)
	if ply.SM64WorldAt and ply.SM64WorldAt > CurTime() - 30 then return end
	ply.SM64WorldAt = CurTime()
	local b = BuildBlob()
	if not b then return end
	local total = math.ceil(#b / CHUNK)
	for i = 1, total do
		-- staggered to avoid overflowing the reliable channel
		timer.Simple(i * 0.05, function()
			if not IsValid(ply) then return end
			local part = string.sub(b, (i - 1) * CHUNK + 1, i * CHUNK)
			net.Start("SM64_WorldChunk")
			net.WriteUInt(i, 16) net.WriteUInt(total, 16)
			net.WriteUInt(#part, 16) net.WriteData(part, #part)
			net.Send(ply)
		end)
	end
end)
