-- Client: drives libsm64 (30 Hz), renders Mario, third-person camera, input capture.
SM64 = SM64 or {}
local S = SM64.SCALE
local TICK = 1 / 30
local cvDist = CreateClientConVar("sm64_cam_dist", "160", true, false)

local active, marioId, marioPos, triCount = false, nil, nil, 0
local accum, texReady, needTex = 0, false, false
local verts, cr, cg, cb, us, vs = {}, {}, {}, {}, {}, {}
local inp = { fwd = false, back = false, left = false, right = false, a = false, b = false, z = false }
local camAng = Angle()
local texRT, texMat, colMat

local function Say(msg) chat.AddText(Color(255, 80, 80), "[SM64] ", color_white, msg) end

-- Source <-> SM64 axes: Source(x,y,z) = SM64(x, -z, y) * S
local function ToSM64(v) return v.x / S, v.z / S, -v.y / S end
local function ToSource(x, y, z) return Vector(x * S, -z * S, y * S) end

local function EnsureModule()
	if libsm64 then return true end
	if not util.IsBinaryModuleInstalled("sm64") then
		local name = (jit.arch == "x64" and (system.IsWindows() and "gmcl_sm64_win64.dll" or "gmcl_sm64_linux64.dll"))
			or (system.IsWindows() and "gmcl_sm64_win32.dll" or "gmcl_sm64_linux.dll")
		Say("Module not found. Put " .. name .. " in garrysmod/lua/bin/ (see README).")
		return false
	end
	local ok, err = pcall(require, "sm64")
	if not ok or not libsm64 then Say("Binary module not found: " .. tostring(err)) return false end
	return true
end

local function EnsureInit()
	if SM64.inited then return true end
	local rom = file.Read(SM64.ROM_PATH, "DATA")
	if not rom then Say("Put your US ROM at garrysmod/data/" .. SM64.ROM_PATH) return false end
	local ok, err = libsm64.Init(rom)
	if not ok then Say(tostring(err)) return false end
	SM64.inited, needTex = true, true
	return true
end

-- Build the 704x64 Mario texture into an RGBA render target (once). Done in PostRender so RT ops are legal.
hook.Add("PostRender", "SM64_BuildTex", function()
	if not needTex then return end
	needTex = false
	local W, H = 704, 64
	local data = libsm64.GetTexture()
	texRT = GetRenderTargetEx("sm64_tex_rt", W, H, RT_SIZE_NO_CHANGE, MATERIAL_RT_DEPTH_NONE, 0, 0, IMAGE_FORMAT_RGBA8888)
	render.PushRenderTarget(texRT)
	render.Clear(0, 0, 0, 0, true, true)
	for y = 0, H - 1 do
		for x = 0, W - 1 do
			local r, g, b, a = string.byte(data, (y * W + x) * 4 + 1, (y * W + x) * 4 + 4)
			render.SetScissorRect(x, y, x + 1, y + 1, true)
			render.Clear(r, g, b, a)
		end
	end
	render.SetScissorRect(0, 0, 0, 0, false)
	render.PopRenderTarget()

	-- Pass 1 (vertex colour) + pass 2 (texture alpha-blended on top) reproduces libsm64's mix(color, tex, tex.a)
	colMat = CreateMaterial("sm64_col_mat", "UnlitGeneric", { ["$basetexture"] = "color/white", ["$vertexcolor"] = 1, ["$nocull"] = 1 })
	texMat = CreateMaterial("sm64_tex_mat", "UnlitGeneric", { ["$basetexture"] = "color/white", ["$vertexcolor"] = 1, ["$translucent"] = 1, ["$nocull"] = 1 })
	texMat:SetTexture("$basetexture", texRT)
	texReady = true
end)

local function Deactivate()
	if marioId and libsm64 then libsm64.MarioDelete(marioId) end
	active, marioId, marioPos, triCount = false, nil, nil, 0
end

local function Activate()
	if not EnsureModule() or not EnsureInit() then RunConsoleCommand("sm64_toggle") return end
	SM64.LoadWorld(function()
		if marioId then libsm64.MarioDelete(marioId) end
		local x, y, z = ToSM64(LocalPlayer():GetPos())
		marioId = libsm64.MarioCreate(x, y + 20, z)
		if marioId < 0 then Say("Could not spawn Mario (no floor found; try sm64_flip_winding 1).") RunConsoleCommand("sm64_toggle") return end
		active = true
	end)
end

net.Receive("SM64_Toggle", function() if net.ReadBool() then Activate() else Deactivate() end end)

local function Tick()
	local fwd = camAng:Forward()
	local sx = (inp.right and 1 or 0) - (inp.left and 1 or 0)
	local sy = (inp.back and 1 or 0) - (inp.fwd and 1 or 0) -- SM64: forward = -Y
	local len = math.sqrt(sx * sx + sy * sy)
	if len > 1 then sx, sy = sx / len, sy / len end

	-- camera look direction in SM64 space (x, -y)
	local st = libsm64.MarioTick(marioId, fwd.x, -fwd.y, sx, sy, inp.a, inp.b, inp.z)
	marioPos = ToSource(st.x, st.y, st.z)

	local n, pos, col, uv = libsm64.GetGeometry()
	triCount = n
	for i = 0, n * 3 - 1 do
		local p = i * 3
		verts[i + 1] = ToSource(pos[p + 1], pos[p + 2], pos[p + 3])
		cr[i + 1], cg[i + 1], cb[i + 1] = math.floor(col[p + 1] * 255), math.floor(col[p + 2] * 255), math.floor(col[p + 3] * 255)
		us[i + 1], vs[i + 1] = uv[i * 2 + 1], uv[i * 2 + 2]
	end

	net.Start("SM64_State", true) net.WriteVector(marioPos) net.SendToServer()
end

hook.Add("Think", "SM64_Tick", function()
	if not active or not marioId then return end
	accum = accum + math.min(FrameTime(), 0.1)
	while accum >= TICK do accum = accum - TICK Tick() end
end)

hook.Add("CreateMove", "SM64_Input", function(cmd)
	if not active then return end
	inp.fwd, inp.back = cmd:KeyDown(IN_FORWARD), cmd:KeyDown(IN_BACK)
	inp.left, inp.right = cmd:KeyDown(IN_MOVELEFT), cmd:KeyDown(IN_MOVERIGHT)
	inp.a, inp.b, inp.z = cmd:KeyDown(IN_JUMP), cmd:KeyDown(IN_ATTACK), cmd:KeyDown(IN_DUCK)
	camAng = cmd:GetViewAngles()
	cmd:ClearMovement()
	cmd:ClearButtons()
end)

hook.Add("CalcView", "SM64_Cam", function(ply, origin, angles, fov)
	if not active or not marioPos then return end
	local focus = marioPos + Vector(0, 0, 50)
	local tr = util.TraceHull({ start = focus, endpos = focus - angles:Forward() * cvDist:GetFloat(),
		mins = Vector(-6, -6, -6), maxs = Vector(6, 6, 6), mask = MASK_SOLID_BRUSHONLY })
	return { origin = tr.HitPos, angles = angles, fov = fov, drawviewer = false }
end)

local function DrawPass(textured)
	mesh.Begin(MATERIAL_TRIANGLES, triCount)
	for i = 1, triCount * 3 do
		mesh.Position(verts[i])
		if textured then mesh.Color(255, 255, 255, 255) else mesh.Color(cr[i], cg[i], cb[i], 255) end
		mesh.TexCoord(0, us[i], vs[i])
		mesh.AdvanceVertex()
	end
	mesh.End()
end

hook.Add("PostDrawOpaqueRenderables", "SM64_Draw", function(depth, sky)
	if sky or not active or not texReady or triCount == 0 then return end
	render.SetMaterial(colMat) DrawPass(false)
	render.SetMaterial(texMat) DrawPass(true)
end)
